El archivo zybomon_data_package.vhd contiene las funciones y procedures propios que utilizan los IPCORES de nuestro proyecto.

No es necesario hacer nada con él, solo está para mostrar la librería.